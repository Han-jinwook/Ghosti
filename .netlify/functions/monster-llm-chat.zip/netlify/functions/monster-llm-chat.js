"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var monster_llm_chat_exports = {};
__export(monster_llm_chat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(monster_llm_chat_exports);
const HUB_GEMINI_URL = process.env.HUB_AI_GATEWAY_URL || "https://os.sundreamer.app/api/ai/gemini";
const HUB_OPENAI_URL = process.env.HUB_OPENAI_GATEWAY_URL || "https://os.sundreamer.app/api/ai/openai";
const JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function reply(status, body) {
  return { statusCode: status, headers: JSON_HEADERS, body: JSON.stringify(body) };
}
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return reply(204, {});
  }
  if (event.httpMethod !== "POST") {
    return reply(405, { ok: false, error: "Method Not Allowed" });
  }
  let body = {};
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return reply(400, { ok: false, error: "Invalid JSON body" });
  }
  const prompt = String(body.prompt || "").trim();
  if (!prompt) {
    return reply(400, { ok: false, error: "Empty prompt" });
  }
  try {
    const res = await fetch(HUB_GEMINI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-client-id": "ghosti",
        "x-ai-account": "beakes"
      },
      body: JSON.stringify({
        appId: "ghosti",
        account: "beakes",
        model: "gemini-2.5-flash",
        messages: [{ role: "user", content: prompt }],
        config: { temperature: 0.45, maxOutputTokens: 600, thinkingConfig: { thinkingBudget: 0 } }
      })
    });
    if (res.ok) {
      const data = await res.json();
      const text = String(data?.text || "").trim();
      if (text) {
        return reply(200, { ok: true, model: "gemini-2.5-flash", text });
      }
    }
  } catch {
  }
  try {
    const res = await fetch(HUB_OPENAI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-client-id": "ghosti",
        "x-ai-account": "beakes"
      },
      body: JSON.stringify({
        appId: "ghosti",
        account: "beakes",
        model: "gpt-4o-mini",
        temperature: 0.4,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (res.ok) {
      const data = await res.json();
      const text = String(data?.text || "").trim();
      if (text) {
        return reply(200, { ok: true, model: "gpt-4o-mini", text });
      }
    }
  } catch {
  }
  const geminiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  if (geminiKey) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiKey}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.45, maxOutputTokens: 600, thinkingConfig: { thinkingBudget: 0 } }
        })
      });
      if (res.ok) {
        const data = await res.json();
        const text = String(data?.candidates?.[0]?.content?.parts?.[0]?.text || "").trim();
        if (text) {
          return reply(200, { ok: true, model: "gemini-2.5-flash-direct", text });
        }
      }
    } catch {
    }
  }
  return reply(502, { ok: false, error: "LLM gateway unavailable" });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
