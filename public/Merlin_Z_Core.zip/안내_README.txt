❖ 멀린 Z-코어 (Merlin Z-Core v2.8.64 · 0.3초 즉시 기동 onedir 에디션) 사용 안내

1. 다운로드한 Merlin_Z_Core.zip의 압축을 한 폴더에 모두 풀어 주세요. (_internal 폴더와 Merlin_Z_Core_Setup.exe가 같은 폴더에 있어야 합니다)
2. [Merlin_Z_Core_Setup.exe]를 더블 클릭하여 실행합니다. (영구 경로 %LOCALAPPDATA%\Programs\MerlinFamily 로 자동 안착됩니다)
3. 실행 후 윈도우 작업표시줄 시계 옆(시스템 트레이)에 귀신같이 아이콘이 생성되며, 이후 PC 재부팅·Ctrl+0 귀신검색창이 0.3초 만에 즉시 열립니다.
4. 귀신같이 웹 브라우저(https://ghosti.sundreamer.app)의 [1. 귀신비서] · [2. 귀신검색] 창으로 돌아가시면
   자동 연결되며, 외부 클라우드 전송 없이 내 컴퓨터 속 진짜 사진·동영상·문서만 조용히 로컬 인덱싱합니다.
5. 이후 신규 버전이 출시되면 별도 다운로드 없이 백그라운드에서 항상 최신 버전으로 자동 업데이트됩니다.
