
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/hub-supabase-bridge.mjs
import crypto from "node:crypto";
var HUB_URL = process.env.MERLIN_HUB_URL || "https://os.sundreamer.app";
var HUB_CLIENT_ID = process.env.MERLIN_HUB_CLIENT_ID || "APP-01";
var HUB_CLIENT_SECRET = process.env.MERLIN_HUB_CLIENT_SECRET || "merlin-family-secret-key-2026";
var TOKEN_TTL_SEC = 60 * 60;
var json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});
var b64url = (input) => Buffer.from(typeof input === "string" ? input : JSON.stringify(input)).toString("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
function signSupabaseJwt({ userId, email }, secret) {
  const now = Math.floor(Date.now() / 1e3);
  const header = b64url({ alg: "HS256", typ: "JWT" });
  const payload = b64url({
    sub: userId,
    email,
    role: "authenticated",
    aud: "authenticated",
    iss: "ghosti-hub-bridge",
    iat: now,
    exp: now + TOKEN_TTL_SEC
  });
  const sig = crypto.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64").replace(/=+$/, "").replace(/\+/g, "-").replace(/\//g, "_");
  return { token: `${header}.${payload}.${sig}`, expiresAt: (now + TOKEN_TTL_SEC) * 1e3 };
}
var hub_supabase_bridge_default = async (req) => {
  if (req.method !== "POST") return json(405, { ok: false, reason: "POST only" });
  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const jwtSecret = process.env.SUPABASE_JWT_SECRET;
  if (!supabaseUrl || !serviceKey || !jwtSecret) {
    return json(500, { ok: false, reason: "\uC11C\uBC84 \uD658\uACBD\uBCC0\uC218 \uBBF8\uC124\uC815 (VITE_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY / SUPABASE_JWT_SECRET)" });
  }
  const auth = req.headers.get("authorization") || "";
  const hubToken = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!hubToken) return json(401, { ok: false, reason: "\uD5C8\uBE0C \uD1A0\uD070 \uC5C6\uC74C" });
  let body = {};
  try {
    body = await req.json();
  } catch {
  }
  let hubUser;
  try {
    const r = await fetch(`${HUB_URL}/api/auth/me?t=${Date.now()}`, {
      headers: {
        Authorization: `Bearer ${hubToken}`,
        "X-Client-Id": HUB_CLIENT_ID,
        "X-Client-Secret": HUB_CLIENT_SECRET
      }
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok || !data?.success || !data?.user) {
      return json(401, { ok: false, reason: `\uD5C8\uBE0C \uD1A0\uD070 \uAC80\uC99D \uC2E4\uD328 (HTTP ${r.status})` });
    }
    hubUser = data.user;
  } catch (e) {
    return json(502, { ok: false, reason: `\uD5C8\uBE0C \uC5F0\uACB0 \uC2E4\uD328: ${e?.message || e}` });
  }
  const userId = String(hubUser.userId || hubUser.id || "").trim();
  const email = String(hubUser.email || "").trim().toLowerCase();
  if (!userId || !email) return json(401, { ok: false, reason: "\uD5C8\uBE0C \uC751\uB2F5\uC5D0 userId/email \uC5C6\uC74C" });
  if (body.userId && String(body.userId).trim() !== userId) {
    return json(403, { ok: false, reason: "\uC694\uCCAD userId\uC640 \uD5C8\uBE0C \uAC80\uC99D userId \uBD88\uC77C\uCE58" });
  }
  const appSettings = {};
  if (body.nativePushToken) {
    appSettings.native_push_token = String(body.nativePushToken);
    appSettings.push_channel_id = "ghosti";
  }
  if (body.signupSource) {
    appSettings.signup_source = String(body.signupSource);
  }
  if (typeof body.launchNotifyOptIn === "boolean") {
    appSettings.launch_notify_opt_in = body.launchNotifyOptIn;
  }
  if (body.devicePlatform) {
    appSettings.device_platform = String(body.devicePlatform);
  }
  appSettings.last_synced_at = (/* @__PURE__ */ new Date()).toISOString();
  const row = {
    id: userId,
    email,
    nickname: hubUser.nickname || body.nickname || email.split("@")[0],
    last_login_at: (/* @__PURE__ */ new Date()).toISOString(),
    app_settings: appSettings
  };
  const up = await fetch(`${supabaseUrl}/rest/v1/users?on_conflict=id`, {
    method: "POST",
    headers: {
      apikey: serviceKey,
      Authorization: `Bearer ${serviceKey}`,
      "Content-Type": "application/json",
      Prefer: "resolution=merge-duplicates,return=minimal"
    },
    body: JSON.stringify(row)
  });
  if (!up.ok) {
    const detail = await up.text().catch(() => "");
    return json(500, { ok: false, reason: `users Upsert \uC2E4\uD328 (HTTP ${up.status})`, detail: detail.slice(0, 300) });
  }
  const { token, expiresAt } = signSupabaseJwt({ userId, email }, jwtSecret);
  return json(200, { ok: true, userId, email, supabaseAccessToken: token, expiresAt });
};
export {
  hub_supabase_bridge_default as default
};
