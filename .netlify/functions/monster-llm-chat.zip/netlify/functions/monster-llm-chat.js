"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var monster_llm_chat_exports = {};
__export(monster_llm_chat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(monster_llm_chat_exports);
const HUB_GEMINI_URL = process.env.HUB_AI_GATEWAY_URL || "https://os.sundreamer.app/api/ai/gemini";
const HUB_OPENAI_URL = process.env.HUB_OPENAI_GATEWAY_URL || "https://os.sundreamer.app/api/ai/openai";
const JSON_HEADERS = {
  "Content-Type": "application/json; charset=utf-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
function reply(status, body) {
  return { statusCode: status, headers: JSON_HEADERS, body: JSON.stringify(body) };
}
async function handler(event) {
  if (event.httpMethod === "OPTIONS") {
    return reply(204, {});
  }
  if (event.httpMethod !== "POST") {
    return reply(405, { ok: false, error: "Method Not Allowed" });
  }
  let body = {};
  try {
    body = JSON.parse(event.body || "{}");
  } catch {
    return reply(400, { ok: false, error: "Invalid JSON body" });
  }
  if (body.action === "transcribe_audio") {
    const audioBase64 = String(body.audioBase64 || "").trim();
    const mimeType = String(body.mimeType || "audio/webm").trim() || "audio/webm";
    if (!audioBase64 || audioBase64.length < 50) {
      return reply(400, { ok: false, error: "Empty audio payload" });
    }
    const sttPrompt = "\uC0AC\uC6A9\uC790\uAC00 \uB9D0\uD55C \uD55C\uAD6D\uC5B4(\uB610\uB294 \uC601\uC5B4) \uC74C\uC131\uC785\uB2C8\uB2E4. \uB4E4\uB9AC\uB294 \uBB38\uC7A5\uB9CC \uC815\uD655\uD788 \uADF8\uB300\uB85C \uD14D\uC2A4\uD2B8\uB85C \uCD9C\uB825\uD558\uC138\uC694. \uBD80\uC5F0 \uC124\uBA85\uC774\uB098 \uB530\uC634\uD45C \uC5C6\uC774 \uBC1C\uD654 \uB0B4\uC6A9\uB9CC \uCD9C\uB825\uD558\uC138\uC694.";
    try {
      const res = await fetch(HUB_GEMINI_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-client-id": "ghosti",
          "x-ai-account": "beakes"
        },
        body: JSON.stringify({
          appId: "ghosti",
          account: "beakes",
          model: "gemini-flash-lite-latest",
          prompt: sttPrompt,
          parts: [
            {
              inlineData: {
                mimeType,
                data: audioBase64
              }
            }
          ],
          temperature: 0.1
        })
      });
      if (res.ok) {
        const data = await res.json();
        const transcript = String(data?.text || "").trim().replace(/^["'“”]+|["'“”]+$/g, "").trim();
        if (transcript) {
          return reply(200, { ok: true, transcript, model: "gemini-flash-lite-hub" });
        }
      }
    } catch {
    }
    const geminiKey2 = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
    if (geminiKey2) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiKey2}`;
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [
              {
                role: "user",
                parts: [
                  { text: sttPrompt },
                  { inlineData: { mimeType, data: audioBase64 } }
                ]
              }
            ],
            generationConfig: { temperature: 0.1, maxOutputTokens: 200 }
          })
        });
        if (res.ok) {
          const data = await res.json();
          const transcript = String(data?.candidates?.[0]?.content?.parts?.[0]?.text || "").trim().replace(/^["'“”]+|["'“”]+$/g, "").trim();
          if (transcript) {
            return reply(200, { ok: true, transcript, model: "gemini-2.5-flash-direct" });
          }
        }
      } catch {
      }
    }
    return reply(200, { ok: false, transcript: "", error: "STT transcription empty" });
  }
  const prompt = String(body.prompt || "").trim();
  if (!prompt) {
    return reply(400, { ok: false, error: "Empty prompt" });
  }
  try {
    const res = await fetch(HUB_GEMINI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-client-id": "ghosti",
        "x-ai-account": "beakes"
      },
      body: JSON.stringify({
        appId: "ghosti",
        account: "beakes",
        model: "gemini-2.5-flash",
        messages: [{ role: "user", content: prompt }],
        config: { temperature: 0.45, maxOutputTokens: 600, thinkingConfig: { thinkingBudget: 0 } }
      })
    });
    if (res.ok) {
      const data = await res.json();
      const text = String(data?.text || "").trim();
      if (text) {
        return reply(200, { ok: true, model: "gemini-2.5-flash", text });
      }
    }
  } catch {
  }
  try {
    const res = await fetch(HUB_OPENAI_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-client-id": "ghosti",
        "x-ai-account": "beakes"
      },
      body: JSON.stringify({
        appId: "ghosti",
        account: "beakes",
        model: "gpt-4o-mini",
        temperature: 0.4,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (res.ok) {
      const data = await res.json();
      const text = String(data?.text || "").trim();
      if (text) {
        return reply(200, { ok: true, model: "gpt-4o-mini", text });
      }
    }
  } catch {
  }
  const geminiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
  if (geminiKey) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${geminiKey}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.45, maxOutputTokens: 600, thinkingConfig: { thinkingBudget: 0 } }
        })
      });
      if (res.ok) {
        const data = await res.json();
        const text = String(data?.candidates?.[0]?.content?.parts?.[0]?.text || "").trim();
        if (text) {
          return reply(200, { ok: true, model: "gemini-2.5-flash-direct", text });
        }
      }
    } catch {
    }
  }
  return reply(502, { ok: false, error: "LLM gateway unavailable" });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
