"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/models-mirror.mjs
var models_mirror_exports = {};
__export(models_mirror_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(models_mirror_exports);
var GH_RELEASE_BASE = "https://github.com/Han-jinwook/Ghosti/releases/download/models-embeddinggemma2-v1";
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Range"
};
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 204, headers: CORS_HEADERS, body: "" };
  }
  const rawPath = String(event.path || "").replace(/^\/\.netlify\/functions\/models-mirror\/?/, "").replace(/^\/api\/models-mirror\/?/, "").replace(/^onnx-community\/embeddinggemma-2-ONNX\/resolve\/[^/]+\//, "").replace(/^\/+/, "");
  if (!rawPath) {
    return {
      statusCode: 400,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ ok: false, error: "MISSING_MODEL_PATH" })
    };
  }
  const assetName = rawPath.replace(/\//g, "__");
  const ghUrl = `${GH_RELEASE_BASE}/${encodeURIComponent(assetName)}`;
  try {
    if (rawPath.endsWith(".json") && !rawPath.endsWith("tokenizer.json")) {
      const res = await fetch(ghUrl, { redirect: "follow" });
      if (!res.ok) {
        return { statusCode: res.status, headers: CORS_HEADERS, body: "" };
      }
      const text = await res.text();
      return {
        statusCode: 200,
        headers: {
          ...CORS_HEADERS,
          "Content-Type": "application/json; charset=utf-8",
          "Cache-Control": "public, max-age=31536000, immutable"
        },
        body: text
      };
    }
    const headRes = await fetch(ghUrl, { method: "GET", redirect: "manual" });
    const cdnLocation = headRes.headers.get("location") || ghUrl;
    return {
      statusCode: 302,
      headers: {
        ...CORS_HEADERS,
        Location: cdnLocation,
        "Cache-Control": "public, max-age=3600"
      },
      body: ""
    };
  } catch (err) {
    return {
      statusCode: 502,
      headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
      body: JSON.stringify({ ok: false, error: String(err?.message || err) })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
