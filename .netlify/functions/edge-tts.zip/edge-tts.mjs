
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/edge-tts.mjs
import tls from "node:tls";
import crypto from "node:crypto";
var TRUSTED_CLIENT_TOKEN = ["6A5AA1D4EAFF4E9F", "B37E23D68491D6F4"].join("");
var CHROMIUM_FULL_VERSION = "143.0.3650.75";
var CHROMIUM_MAJOR_VERSION = "143";
var SEC_MS_GEC_VERSION = `2-${CHROMIUM_FULL_VERSION}`;
var WIN_EPOCH = 11644473600;
var SHA256_INITIAL = [
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
];
var SHA256_STATE = [
  4255104674,
  2435071207,
  3192492180,
  3442351626,
  1811967817,
  79508907,
  4272990180,
  66059218
];
var SHA256_SCHEDULE = [
  3945054110,
  358115615,
  2696978146,
  217723578,
  2787307148,
  3520959633,
  3235718560,
  4192668342,
  4039316851,
  1884868174,
  1904797190,
  15051571,
  3529027680,
  1920361828
];
var SHA256_ROUND_CONSTANTS = [
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
];
var SHA256_ADJUSTMENT = 3386640039;
var SHA256_BLOCK_CONSTANTS = [
  ...SHA256_ROUND_CONSTANTS.slice(0, 14),
  SHA256_ADJUSTMENT,
  ...SHA256_ROUND_CONSTANTS.slice(15)
];
var SHA256_SIGMA0_ADJUSTMENT = 94112640;
var SHA256_SIGMA1_ADJUSTMENT = 758464;
var CS64_COEFFICIENTS = [
  [3895366065, 3005677776],
  [1155409094, 2296378653],
  [1005282748, 693190712],
  [3365689651, 3005795295],
  [2367603217, 3557143765],
  [827258325, 652566332],
  [3911487921, 1618477510],
  [4037392853, 2192753147],
  [101076211, 4199654362],
  [3665427040, 545047652],
  [3201434976, 1010595059],
  [2314848760, 3536931681],
  [905590982, 3137643201],
  [3410617286, 3311559015]
];
var CS64_FACTOR = 2190031155;
var CS64_ADJUSTMENT0 = 4076407578;
var CS64_ADJUSTMENT1 = 186253312;
function u32(v) {
  return Number(BigInt(v) & 0xffffffffn);
}
function mul32(a, b) {
  return Number(BigInt(a >>> 0) * BigInt(b >>> 0) & 0xffffffffn);
}
function add32(...vals) {
  let s = 0n;
  for (const v of vals) {
    s = s + BigInt(v >>> 0) & 0xffffffffn;
  }
  return Number(s);
}
function rotr32(v, n) {
  const x = v >>> 0;
  return (x >>> n | x << 32 - n) >>> 0;
}
function rol16(v) {
  const x = v >>> 0;
  return (x << 16 | x >>> 16) >>> 0;
}
function sigma0(v) {
  const x = v >>> 0;
  return (rotr32(x, 7) ^ rotr32(x, 18) ^ x >>> 3) >>> 0;
}
function sigma1(v) {
  const x = v >>> 0;
  return (rotr32(x, 17) ^ rotr32(x, 19) ^ x >>> 10) >>> 0;
}
function bigSigma0(v) {
  const x = v >>> 0;
  return (rotr32(x, 2) ^ rotr32(x, 13) ^ rotr32(x, 22)) >>> 0;
}
function bigSigma1(v) {
  const x = v >>> 0;
  return (rotr32(x, 6) ^ rotr32(x, 11) ^ rotr32(x, 25)) >>> 0;
}
function sha256Rounds(state, words, firstRound = 0) {
  let [a, b, c, d, e, f, g, h] = state.map((x) => x >>> 0);
  const constants = firstRound === 14 ? SHA256_BLOCK_CONSTANTS : SHA256_ROUND_CONSTANTS;
  for (let i = firstRound; i < 64; i++) {
    const ch = (g ^ e & (f ^ g)) >>> 0;
    const maj = (a & b | c & (a | b)) >>> 0;
    const t1 = add32(h, bigSigma1(e), ch, constants[i], words[i]);
    const t2 = add32(bigSigma0(a), maj);
    h = g;
    g = f;
    f = e;
    e = add32(d, t1);
    d = c;
    c = b;
    b = a;
    a = add32(t1, t2);
  }
  return [a, b, c, d, e, f, g, h];
}
function expandSha256Schedule(words, firstWord = 16) {
  for (let i = firstWord; i < 64; i++) {
    words.push(add32(sigma1(words[i - 2]), words[i - 7], sigma0(words[i - 15]), words[i - 16]));
  }
}
function sha256Init(data7) {
  const w14 = data7[0] << 16 | data7[1] << 8 | data7[2];
  const w15 = data7.readUInt32BE(3);
  const words = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w14 >>> 0, w15 >>> 0];
  for (let index = 16; index < 30; index++) {
    let value = SHA256_SCHEDULE[index - 16] >>> 0;
    if (index - 2 >= 14) {
      const s1 = index === 16 ? (sigma1(words[index - 2]) ^ SHA256_SIGMA1_ADJUSTMENT) >>> 0 : sigma1(words[index - 2]);
      value = add32(value, s1);
    }
    if (index - 7 >= 14) {
      value = add32(value, words[index - 7]);
    }
    if (index - 15 >= 14) {
      const s0 = index === 29 ? (sigma0(words[index - 15]) ^ SHA256_SIGMA0_ADJUSTMENT) >>> 0 : sigma0(words[index - 15]);
      value = add32(value, s0);
    }
    words.push(value);
  }
  const w30 = u32(
    BigInt(sigma1(words[28])) + BigInt(words[23]) + BigInt(sigma0(words[15])) + BigInt(words[14]) + BigInt(SHA256_ADJUSTMENT) - BigInt(SHA256_ROUND_CONSTANTS[14])
  );
  words.push(w30);
  expandSha256Schedule(words, 31);
  const working = sha256Rounds(SHA256_STATE, words, 14);
  return SHA256_INITIAL.map((x, idx) => add32(x, working[idx]));
}
function sha256Digest(dataBuf) {
  const length = 57 + dataBuf.length;
  const padZeros = ((55 - length) % 64 + 64) % 64;
  const tail = dataBuf.subarray(7);
  const padded = Buffer.alloc(tail.length + 1 + padZeros + 8);
  tail.copy(padded, 0);
  padded[tail.length] = 128;
  padded.writeBigUInt64BE(BigInt(length * 8), padded.length - 8);
  let state = sha256Init(dataBuf.subarray(0, 7));
  for (let offset = 0; offset < padded.length; offset += 64) {
    const words = [];
    for (let i = 0; i < 16; i++) {
      words.push(padded.readUInt32BE(offset + i * 4));
    }
    expandSha256Schedule(words, 16);
    const working = sha256Rounds(state, words, 0);
    state = state.map((x, idx) => add32(x, working[idx]));
  }
  const out = Buffer.alloc(32);
  for (let i = 0; i < 8; i++) {
    out.writeUInt32BE(state[i] >>> 0, i * 4);
  }
  return out;
}
function wordsLe4Even(buf) {
  const rem = (4 - buf.length % 4) % 4;
  const padded = rem > 0 ? Buffer.concat([buf, Buffer.alloc(rem)]) : buf;
  const words = [];
  for (let i = 0; i < padded.length; i += 4) {
    words.push(padded.readUInt32LE(i));
  }
  if (words.length % 2 === 1) {
    words.push(0);
  }
  return words;
}
function cs64Digest(dataBuf, digestBuf) {
  const keyA = (digestBuf.readUInt32LE(0) | 1) >>> 0;
  const keyB = (digestBuf.readUInt32LE(4) | 1) >>> 0;
  const factors = [mul32(keyA, CS64_FACTOR), mul32(keyB, CS64_FACTOR)];
  const terms = CS64_COEFFICIENTS.map(([coeff], idx) => mul32(coeff, factors[idx % 2]));
  const offsets = CS64_COEFFICIENTS.map(([, off]) => off >>> 0);
  const inputWords = wordsLe4Even(Buffer.concat([Buffer.from([0]), dataBuf]));
  for (let index = 0; index < inputWords.length; index++) {
    const word = inputWords[index] >>> 0;
    let term = BigInt(word) * BigInt(index % 2 === 0 ? keyA : keyB);
    let offset = BigInt(rol16(word)) * BigInt(index % 2 === 0 ? 4010109435 : 3273069531);
    if (index === 0) {
      term += BigInt(CS64_ADJUSTMENT0) * BigInt(factors[0]);
      offset += BigInt(CS64_ADJUSTMENT1);
    }
    terms.push(Number(term & 0xffffffffn));
    offsets.push(Number(offset & 0xffffffffn));
  }
  let swapAcc = 0;
  let swapLast = 0;
  let state = 0;
  let acc = 0;
  for (let index = 0; index < terms.length; index += 2) {
    const x = terms[index] >>> 0;
    const y = terms[index + 1] >>> 0;
    let t = rol16(add32(offsets[index], x));
    let q = mul32(t, 1995771700);
    swapAcc = add32(swapAcc, add32(mul32(rol16(q), 3287280279), q));
    t = rol16(add32(offsets[index + 1], y));
    q = mul32(t, 411160124);
    swapLast = add32(mul32(rol16(q), 901586633), q);
    swapAcc = add32(swapAcc, swapLast);
    state = add32(mul32(state, keyA), x);
    state = mul32(rol16(state), 3482890513);
    state = mul32(rol16(state), 2265471903);
    state = mul32(rol16(state), 315537773);
    state = mul32(rol16(state), 629022083);
    acc = add32(acc, state);
    t = add32(mul32(state, keyB), y);
    t = mul32(rol16(t), 2725517045);
    t = mul32(rol16(t), 3548616447);
    state = mul32(rol16(mul32(rol16(t), 2090019721)), 3215236969);
    acc = add32(acc, state);
  }
  return [(swapLast ^ state) >>> 0, (swapAcc ^ acc) >>> 0];
}
function generateSecMsGecV2(unixTimestampSec = Math.floor(Date.now() / 1e3)) {
  let ticks = unixTimestampSec + WIN_EPOCH;
  ticks -= ticks % 300;
  const ticks100ns = BigInt(ticks) * 10000000n;
  const strToHash = `${ticks100ns.toString()}${TRUSTED_CLIENT_TOKEN}`;
  const dataBuf = Buffer.from(strToHash, "ascii");
  const digest = sha256Digest(dataBuf);
  const [cs0, cs1] = cs64Digest(dataBuf, digest);
  const csBuf = Buffer.alloc(8);
  csBuf.writeUInt32LE(cs0, 0);
  csBuf.writeUInt32LE(cs1, 4);
  return `${csBuf.toString("hex").toUpperCase()}-${digest.toString("hex").toUpperCase()}`;
}
function escapeXml(str) {
  return String(str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function createWsTextFrame(str) {
  const payload = Buffer.from(str, "utf8");
  const mask = crypto.randomBytes(4);
  let header;
  if (payload.length < 126) {
    header = Buffer.alloc(2);
    header[0] = 129;
    header[1] = 128 | payload.length;
  } else if (payload.length < 65536) {
    header = Buffer.alloc(4);
    header[0] = 129;
    header[1] = 128 | 126;
    header.writeUInt16BE(payload.length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 129;
    header[1] = 128 | 127;
    header.writeBigUInt64BE(BigInt(payload.length), 2);
  }
  const masked = Buffer.alloc(payload.length);
  for (let i = 0; i < payload.length; i++) {
    masked[i] = payload[i] ^ mask[i % 4];
  }
  return Buffer.concat([header, mask, masked]);
}
function synthesizeEdgeNeuralMp3({ text, voice, rate = "+15%" }) {
  return new Promise((resolve, reject) => {
    const connectionId = crypto.randomBytes(16).toString("hex");
    const muid = crypto.randomBytes(16).toString("hex").toUpperCase();
    const secMsGec = generateSecMsGecV2();
    const wsKey = crypto.randomBytes(16).toString("base64");
    const host = "speech.platform.bing.com";
    const pathUrl = `/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=${TRUSTED_CLIENT_TOKEN}&ConnectionId=${connectionId}&Sec-MS-GEC=${secMsGec}&Sec-MS-GEC-Version=${SEC_MS_GEC_VERSION}`;
    const socket = tls.connect({ host, port: 443, servername: host }, () => {
      const reqLines = [
        `GET ${pathUrl} HTTP/1.1`,
        `Host: ${host}`,
        `Pragma: no-cache`,
        `Cache-Control: no-cache`,
        `User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${CHROMIUM_MAJOR_VERSION}.0.0.0 Safari/537.36 Edg/${CHROMIUM_MAJOR_VERSION}.0.0.0`,
        `Origin: chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold`,
        `Accept-Encoding: gzip, deflate, br, zstd`,
        `Accept-Language: en-US,en;q=0.9`,
        `Cookie: muid=${muid};`,
        `Upgrade: websocket`,
        `Connection: Upgrade`,
        `Sec-WebSocket-Key: ${wsKey}`,
        `Sec-WebSocket-Version: 13`,
        `\r
`
      ];
      socket.write(reqLines.join("\r\n"));
    });
    let upgraded = false;
    let rxBuf = Buffer.alloc(0);
    const audioChunks = [];
    let settled = false;
    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        socket.destroy();
        reject(new Error("Edge TTS synthesis timeout"));
      }
    }, 8500);
    const finishOk = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.destroy();
      const fullAudio = Buffer.concat(audioChunks);
      if (fullAudio.length < 128) {
        reject(new Error("Empty audio buffer"));
      } else {
        resolve(fullAudio);
      }
    };
    const finishErr = (err) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.destroy();
      reject(err);
    };
    socket.on("error", finishErr);
    socket.on("end", () => {
      if (!settled) {
        if (audioChunks.length > 0) finishOk();
        else finishErr(new Error("Socket closed before turn.end"));
      }
    });
    socket.on("data", (chunk) => {
      rxBuf = Buffer.concat([rxBuf, chunk]);
      if (!upgraded) {
        const idx = rxBuf.indexOf("\r\n\r\n");
        if (idx === -1) return;
        const headerStr = rxBuf.subarray(0, idx).toString("utf8");
        rxBuf = rxBuf.subarray(idx + 4);
        if (!headerStr.startsWith("HTTP/1.1 101")) {
          finishErr(new Error(`Handshake failed: ${headerStr.split("\r\n")[0]}`));
          return;
        }
        upgraded = true;
        const nowStr = (/* @__PURE__ */ new Date()).toString();
        const configMsg = `X-Timestamp:${nowStr}\r
Content-Type:application/json; charset=utf-8\r
Path:speech.config\r
\r
{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"true","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}\r
`;
        socket.write(createWsTextFrame(configMsg));
        const reqId = crypto.randomBytes(16).toString("hex");
        const ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='ko-KR'><voice name='${voice}'><prosody pitch='+0Hz' rate='${rate}' volume='+0%'>${escapeXml(text)}</prosody></voice></speak>`;
        const ssmlMsg = `X-RequestId:${reqId}\r
Content-Type:application/ssml+xml\r
X-Timestamp:${nowStr}Z\r
Path:ssml\r
\r
` + ssml;
        socket.write(createWsTextFrame(ssmlMsg));
      }
      while (rxBuf.length >= 2) {
        const byte0 = rxBuf[0];
        const byte1 = rxBuf[1];
        const opcode = byte0 & 15;
        const isMasked = (byte1 & 128) !== 0;
        let payloadLen = byte1 & 127;
        let offset = 2;
        if (payloadLen === 126) {
          if (rxBuf.length < 4) return;
          payloadLen = rxBuf.readUInt16BE(2);
          offset = 4;
        } else if (payloadLen === 127) {
          if (rxBuf.length < 10) return;
          payloadLen = Number(rxBuf.readBigUInt64BE(2));
          offset = 10;
        }
        if (isMasked) offset += 4;
        if (rxBuf.length < offset + payloadLen) return;
        let payload = rxBuf.subarray(offset, offset + payloadLen);
        if (isMasked) {
          const maskKey = rxBuf.subarray(offset - 4, offset);
          payload = Buffer.from(payload);
          for (let i = 0; i < payload.length; i++) {
            payload[i] ^= maskKey[i % 4];
          }
        }
        rxBuf = rxBuf.subarray(offset + payloadLen);
        if (opcode === 1) {
          const textFrame = payload.toString("utf8");
          if (textFrame.includes("Path:turn.end")) {
            finishOk();
            return;
          }
        } else if (opcode === 2 && payload.length >= 2) {
          const headerLen = payload.readUInt16BE(0);
          if (headerLen + 2 <= payload.length) {
            const headerPart = payload.subarray(2, 2 + headerLen).toString("utf8");
            if (headerPart.includes("Path:audio")) {
              const audioData = payload.subarray(2 + headerLen);
              if (audioData.length > 0) {
                audioChunks.push(audioData);
              }
            }
          }
        } else if (opcode === 8) {
          finishOk();
          return;
        }
      }
    });
  });
}
var edge_tts_default = async (req) => {
  const corsHeaders = {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS"
  };
  if (req.method === "OPTIONS") {
    return new Response("{}", { status: 200, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ ok: false, error: "POST only" }), {
      status: 405,
      headers: corsHeaders
    });
  }
  try {
    const body = await req.json().catch(() => ({}));
    const rawText = String(body?.text || "").trim().replace(/\s+/g, " ").slice(0, 600);
    if (!rawText) {
      return new Response(JSON.stringify({ ok: false, error: "EMPTY_TEXT" }), {
        status: 400,
        headers: corsHeaders
      });
    }
    const reqVoice = String(body?.voice || "").toLowerCase();
    const isFemale = reqVoice.includes("sunhi") || reqVoice.includes("female") || reqVoice.includes("yujin");
    const voice = isFemale ? "ko-KR-SunHiNeural" : "ko-KR-HyunsuNeural";
    const rate = String(body?.rate || "+15%");
    const t0 = Date.now();
    const mp3Buffer = await synthesizeEdgeNeuralMp3({ text: rawText, voice, rate });
    const elapsedMs = Date.now() - t0;
    return new Response(
      JSON.stringify({
        ok: true,
        voice,
        voiceActor: isFemale ? "\uC120\uD76C (ko-KR-SunHiNeural \xB7 \uC5EC\uC131 \uC131\uC6B0)" : "\uD604\uC218 (ko-KR-HyunsuNeural \xB7 \uB0A8\uC131 \uC131\uC6B0)",
        audioDataUrl: `data:audio/mpeg;base64,${mp3Buffer.toString("base64")}`,
        byteLength: mp3Buffer.length,
        elapsedMs
      }),
      { status: 200, headers: corsHeaders }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ ok: false, error: String(err?.message || err) }),
      { status: 500, headers: corsHeaders }
    );
  }
};
export {
  edge_tts_default as default,
  generateSecMsGecV2,
  synthesizeEdgeNeuralMp3
};
